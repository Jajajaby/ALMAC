
package almac;

import Modelo.Conexion;

/**
 *
 * @author Javie
 */
public class ALMAC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conexion c = new Conexion();
        
        c.getConexion();
        
    }
    
}
