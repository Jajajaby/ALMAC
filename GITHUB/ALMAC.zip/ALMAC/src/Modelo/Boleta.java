package Modelo;

import java.sql.*;
import java.util.ArrayList;


public class Boleta{
    Conexion c;
    int num_boleta;
    String hora_boleta;
    String fecha_boleta;
    int total_boleta;
    

    public Boleta() {
        c = new Conexion();
    }
    
    public Boleta(int num_boleta, String hora_boleta, String fecha_boleta, int total_boleta) {
        c = new Conexion();
        this.num_boleta = num_boleta;
        this.hora_boleta = hora_boleta;
        this.fecha_boleta = fecha_boleta;
        this.total_boleta = total_boleta;
    }

    public int getNum_boleta() { return num_boleta; }
    public void setNum_boleta(int num_boleta) { this.num_boleta = num_boleta; }
    public String getHora_boleta() { return hora_boleta; }
    public void setHora_boleta(String hora_boleta) { this.hora_boleta = hora_boleta; }
    public String getFecha_boleta() { return fecha_boleta; } 
    public void setFecha_boleta(String fecha_boleta) { this.fecha_boleta = fecha_boleta; } 
    public int getTotal_boleta() { return total_boleta; } 
    public void setTotal_boleta(int total_boleta) { this.total_boleta = total_boleta; }
    
    /* * * * * * * * * * * * * * * * * 
     *  INSERTAR EN TABLA BOLETA     *
     * * * * * * * * * * * * * * * * */
    
    public String insertarBoleta(int num_boleta, String hora, String fecha, int total){
        String rptaRegistro = null;
        
        try{
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("INSERT INTO boleta (id_boleta, hora, fecha, precio) VALUES(?, ?, ?, ?);");
            ps.setInt(1, num_boleta);
            ps.setString(2, hora);
            ps.setString(3, fecha);
            ps.setInt(4, total);
            
            int numFAfectadas = ps.executeUpdate();
            
            if(numFAfectadas > 0)
                rptaRegistro = "Registro exitoso.";
        }catch(SQLException e){
         // vacio.  
        }
        return rptaRegistro = null;
    }
    
    
    /* * * * * * * * * * * * * * * * * 
     *  LISTAR DESDE TABLA BOLETA    *
     * * * * * * * * * * * * * * * * */
    
    public ArrayList<Boleta> listBoleta(){
        ArrayList listaBoleta = new ArrayList();
        Boleta boleta;
        
        try {
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("SELECT * FROM boleta;");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                boleta = new Boleta();
                
                boleta.setNum_boleta(rs.getInt(1));
                boleta.setHora_boleta(rs.getString(2));
                boleta.setFecha_boleta(rs.getString(3));
                boleta.setTotal_boleta(rs.getInt(4));
            }
        } catch (SQLException e) {
            // vacio;
        }
        return listaBoleta;
    }
}
