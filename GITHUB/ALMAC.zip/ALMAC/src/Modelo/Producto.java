package Modelo;

import java.sql.*;
import java.util.ArrayList;

/* *
 * @author 
 */
public class Producto {
    Conexion c; 
    int id_producto;
    String nombre_producto;
    int precio_producto;

    public Producto() {
        c = new Conexion();
    }

    public Producto(int id_producto, String nombre_producto, int precio_producto) {
        c = new Conexion();
        this.id_producto = id_producto;
        this.nombre_producto = nombre_producto;
        this.precio_producto = precio_producto;
    }

    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public String getNombre_producto() { return nombre_producto; }
    public void setNombre_producto(String nombre_producto) { this.nombre_producto = nombre_producto; }
    public int getPrecio_producto() { return precio_producto; }
    public void setPrecio_producto(int precio_producto) { this.precio_producto = precio_producto; }
    
    /* * * * * * * * * * * * * * * * * 
     *  INSERTAR EN TABLA PRODUCTO   *
     * * * * * * * * * * * * * * * * */
    
    public String insertarProducto(int id, String nombre, int precio){
        String rptaRegistro = null;
        
        try{
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("INSERT INTO producto (id_producto, nombre, precio) VALUES(?, ?, ?);");
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.setInt(3, precio);
            
            int numFAfectadas = ps.executeUpdate();
            
            if(numFAfectadas > 0)
                rptaRegistro = "Registro exitoso.";
        }catch(SQLException e){
         // vacio.  
        }
        return rptaRegistro;
    }
    
    
    /* * * * * * * * * * * * * * * * * 
     *  LISTAR DESDE TABLA PRODUCTO  *
     * * * * * * * * * * * * * * * * */
    
    public ArrayList<Producto> listProducto(){
        ArrayList listaProductos = new ArrayList();
        Producto producto;
        
        try {
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("SELECT * FROM producto;");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                producto = new Producto();
                
                producto.setId_producto(rs.getInt(1));
                producto.setNombre_producto(rs.getString(2));
                producto.setPrecio_producto(rs.getInt(3));
                
                listaProductos.add(producto);
            }
            
        } catch (SQLException e){
            // vacio.
        }
        return listaProductos;
    }
    
    
    
}
