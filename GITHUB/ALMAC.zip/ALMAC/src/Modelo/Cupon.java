package Modelo;

import java.sql.*;
import java.util.ArrayList;

/* *
 * @author 
 */

public class Cupon {
    Conexion c;
    int id_cupon;
    int id_producto;
    int dscto_cupon;
    int estado;

    public Cupon() {
        c = new Conexion();
    }
    
    public Cupon(int id_cupon, int id_producto, int dscto_cupon, int estado) {
        c = new Conexion();
        this.id_cupon = id_cupon;
        this.id_producto = id_producto;
        this.dscto_cupon = dscto_cupon;
        this.estado = estado;
    }

    public int getId_cupon() { return id_cupon; }
    public void setId_cupon(int id_cupon) {  this.id_cupon = id_cupon; }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    public int getDscto_cupon() { return dscto_cupon; }
    public void setDscto_cupon(int dscto_cupon) { this.dscto_cupon = dscto_cupon; }
    public int getEstado() { return estado; }
    public void setEstado(int estado) { this.estado = estado; }
    
    /* * * * * * * * * * * * * * * * * 
     *  INSERTAR EN TABLA CUPON      *
     * * * * * * * * * * * * * * * * */
    
    public String insertarCupon(int id_cupon, int id_producto, int dscto, int estado){
        String rptaRegistro = null;
        
        try{
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("INSERT INTO cupon (id_cupon, dscto_cupon, producto_id_producto, estado) VALUES(?, ?, ?, ?);");
            ps.setInt(1, id_cupon);
            ps.setInt(2, dscto);
            ps.setInt(3, id_producto);
            ps.setInt(4, estado);
            
            int numFAfectadas = ps.executeUpdate();
            
            if(numFAfectadas > 0)
                rptaRegistro = "Registro exitoso.";
        }catch(SQLException e){
         // vacio.  
        }
        return rptaRegistro;
    }
    
    /* * * * * * * * * * * * * * * * * 
     *  LISTAR DESDE TABLA CUPON     *
     * * * * * * * * * * * * * * * * */
    
    public ArrayList<Cupon> listProducto(){
        ArrayList listaCupon = new ArrayList();
        Cupon cupon;
        
         try {
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("SELECT * FROM cupon;");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                cupon = new Cupon();
                
                cupon.setId_cupon(rs.getInt(1));
                cupon.setDscto_cupon(rs.getInt(2));
                cupon.setId_producto(rs.getInt(3));
                cupon.setEstado(rs.getInt(4));
                
                listaCupon.add(cupon);
            }
        } catch (SQLException e){
            // vacio.
        }
        return listaCupon;
    }
}

