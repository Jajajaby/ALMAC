package Modelo;

import java.sql.*;
import java.util.ArrayList;


/* *
 * @author 
 */
public class Cte_frecuente {
    Conexion c;
    int RUN_cte;
    String nombre_cte;
    int dscto_cte;
    int id_producto;

    public Cte_frecuente() {
        c = new Conexion();
    }
    
    public Cte_frecuente(int RUN_cte, String nombre_cte, int dscto_cte, int id_producto) {
        c = new Conexion();
        this.RUN_cte = RUN_cte;
        this.nombre_cte = nombre_cte;
        this.dscto_cte = dscto_cte;
        this.id_producto = id_producto;
    }

    public int getRUN_cte() { return RUN_cte; }
    public void setRUN_cte(int RUN_cte) { this.RUN_cte = RUN_cte; }
    public String getNombre_cte() { return nombre_cte; }
    public void setNombre_cte(String nombre_cte) { this.nombre_cte = nombre_cte; }
    public int getDscto_cte() { return dscto_cte; }
    public void setDscto_cte(int dscto_cte) { this.dscto_cte = dscto_cte; }
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }
    
    
    /* * * * * * * * * * * * * * * * * * * * * 
     *  INSERTAR EN TABLA CTE_FRECUENTE      *
     * * * * * * * * * * * * * * * * * * * * */
    
    public String insertarCteFrecuente( int rut, String nombre, int dscto, int id_producto){
        String rptaRegistro = null;
        
        try{
            Connection accesoDB = c.getConexion();
            PreparedStatement ps = accesoDB.prepareStatement("INSERT INTO cte_frecuente (run_cte, nombre, dscto_cte, producto_id_producto) VALUES(?, ?, ?, ?);");
            ps.setInt(1, rut);
            ps.setString(2, nombre);
            ps.setInt(3, dscto);
            ps.setInt(4, id_producto);
            
            int numFAfectadas = ps.executeUpdate();
            
            if(numFAfectadas > 0)
                rptaRegistro = "Registro exitoso.";
        }catch(SQLException e){
         // vacio.  
        }
        return rptaRegistro = null;
    }
    
    /* * * * * * * * * * * * * * * * * * * * *
     *  LISTAR DESDE TABLA CTE_FRECUENTE     *
     * * * * * * * * * * * * * * * * * * * * */
    
    public ArrayList<Cte_frecuente> listCteFrecuente(){
        ArrayList listaCteFrecuente = new ArrayList();
        Cte_frecuente cteFrecuente;
        
        try{
           Connection accesoDB = c.getConexion();
           PreparedStatement ps = accesoDB.prepareStatement("SELECT * FROM cte_frecuente;");
           ResultSet rs = ps.executeQuery();
           
           while(rs.next()){
               cteFrecuente = new Cte_frecuente();
               
               cteFrecuente.setRUN_cte(rs.getInt(1));
               cteFrecuente.setNombre_cte(rs.getString(2));
               cteFrecuente.setDscto_cte(rs.getInt(3));
               cteFrecuente.setId_producto(rs.getInt(4));
               
               listaCteFrecuente.add(cteFrecuente);
           }      
        } catch (SQLException e) {
            // vacio.
        }
        return listaCteFrecuente;
    }
}
