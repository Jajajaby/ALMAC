package Modelo;
import java.sql.*;

public class Conexion{ 
    
    public Conexion(){

    }

    public Connection getConexion(){
        Connection con = null;
        String bdd = "ALMAC";
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+bdd, "root", "Jabiera1305");
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Error! al abrir"+bdd);
        }
        return con;
    }
    
}
